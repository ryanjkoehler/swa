<?php
/**
* Description of Template goes here
*
Template Name: Page
*/

?>


<?php get_header(); ?>

<?php 
global $wp_query;
$term = $wp_query->get_queried_object();
$taxonomy = $term->taxonomy; // This is the Taxonomy Title
$taxonomy_term = $term->name; 



//print_r($wp_query);
//var_dump(get_defined_vars());

$getsubject = htmlspecialchars($_GET["subjects"]);
$getdemographic = htmlspecialchars($_GET["demographic"]);

if(!empty($getsubject) && !empty($getdemographic)) { $and = " and "; }

$propersubject = get_term_by( 'slug', $getsubject, 'subjects');
//echo $propersubject->name;
$properdemographic = get_term_by( 'slug', $getdemographic, 'demographic');
//echo $properdemographic->name;

?>

<!-- <h2 class="sp-header"><?php echo $taxonomy; /*** This is the title of the taxonomy -- such as "Subjects" or "Demographics" ***/ ?></h2>  -->
<div id="intro">
<h1>Chart results for <?php echo $propersubject->name . $and . $properdemographic->name; ?></h1>
</div>
<?php query_posts("subjects=$getsubject&demographic=$getdemographic&posts_per_page=-1&post_type=post"); ?>		
<?php if ( $query ) : ?>

<?php get_template_part( 'loop', 'charts' ) ?>

<?php else : ?>
<?php endif; ?>

</div>



<?php get_sidebar() ?>

<?php get_footer(); ?>