<?php
/**
 * The template for displaying Search Results pages.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */
?>

		<?php get_header(); ?>

		<?php 
				$searchterm = get_search_query();
//				$mySearch =& new WP_Query("s=$s & showposts=-1");
				$mySearch =& new WP_Query("$query_string & showposts=-1");
				$numtotal = $mySearch->post_count; // overridden below
				
				$searchterm = get_search_query();
//				$mySearch =& new WP_Query("s=$s & showposts=-1 & post_type=post");
				$mySearch =& new WP_Query("$query_string & showposts=-1 & post_type=post");
				$numposts = $mySearch->post_count;
				
				$searchterm = get_search_query();
//				$mySearch =& new WP_Query("s=$s & showposts=-1 & post_type=page");
				$mySearch =& new WP_Query("$query_string & showposts=-1 & post_type=page");
				
				$numpages = $mySearch->post_count;
				$numtotal = $numpages + $numposts;
				
		 ?>

			<!-- <h2 class="sp-header"><?php echo $taxonomy; /*** This is the title of the taxonomy -- such as "Subjects" or "Demographics" ***/ ?></h2>  -->
				<div id="intro">
					<h1>Search results for "<?php echo $searchterm; ?>" <span style="color:#aaa;">(<?php echo $numtotal; ?>)</span></h1>
								

					<?php $query = query_posts("$query_string&posts_per_page=3&post_type=page"); ?>
					<?php // $num = $query->post_count; ?>
					
					
					<h3 class="search"><?php echo $numpages; ?> page<?php if ($numpages!=1) echo 's'; ?> and <?php echo $numposts; ?> chart<?php if ($numposts!=1) echo 's'; ?> were found.</h3>

<?php get_template_part( 'loop', 'search' ) ?>

<div class="navigation" style="text-align:right;"><p><?php posts_nav_link(); ?></p></div>

<?php wp_reset_query(); ?>  

					
			
				
				<?php if ($numposts == 0) { ?> 
					
				<?php } elseif ($numposts > 0) { ?>
					<?php $query = query_posts("$query_string&posts_per_page=-1&post_type=post"); ?>			
				
				<h3 class="search"><?php echo $numposts; ?> chart<?php if ($numpages!=1) echo 's'; ?> found.</h3>
				
<?php get_template_part( 'loop', 'charts' ) ?>

<?php } ?>

			</div>

</div><!-- /.intro???????-->

		<?php get_sidebar() ?>

		<?php get_footer(); ?>