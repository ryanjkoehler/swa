<?php get_header(); ?>
<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>

<h2 class="sp-header">Chart Detail</h2>
<div class="detail data-detail">
<h1><?php the_title(); ?></h1>
<div class="chart">

<?php if (function_exists('the_subheading')) { the_subheading('<h2>', '</h2>'); } ?>



<a href="/<?php $key="Chart Image"; echo get_post_meta($post->ID, $key, true); ?>">
<img src="/m/?src=/media/images/big/<?php $key="Chart Cropped"; echo get_post_meta($post->ID, $key, true); ?>&w=640" alt="Chart: <?php the_title_attribute(); ?>" /></a>					
</div>
<div class="source">
</div>

<div class="meta">
<h4>Subject</h4>
<ul>
<li>
<?php the_terms( $post->ID, 'subjects', '', ', ', ' ' ); ?>
</li>			</ul>
</div>
<div class="meta">
<h4>Demographic</h4>
<ul>
<li><?php the_terms( $post->ID, 'demographic', '', ', ', ' ' ); ?></li>			</ul>
</div>

<?php if (is_object_in_term($post->ID,'feature') ) { ?>
<div class="meta">
<ul>This chart is part of the
<li><strong><?php the_terms( $post->ID, 'feature', '', ', ', ' ' ); ?></strong></li> feature.</ul>
</div>
<?php } ?>


</div>
<div class="utilities">
<div class="print-feature">
</div>
<div class="download-share">
<span class="downloads">Download:
<ul> 
<!--	<li><a href="#" class="pdf">PDF</a></li> -->
<li><a href="/media/files/<?php $key="Excel File"; echo get_post_meta($post->ID, $key, true); ?>" class="excel">Excel</a></li>
<li><a href="/media/images/orig/<?php echo get_post_meta($post->ID, "Chart Image", true) ?>" class="hires">Hi-Res</a></li>
</ul>
</span>
<span class="embed-feature"></span>
<span class="share-chart">Share: <a class="addthis_button" href="http://www.addthis.com/bookmark.php"><img src="http://s7.addthis.com/static/btn/sm-plus.gif" width="16" height="16" alt="Share" /></a></span>
</div>
</div>
</div>
<?php endwhile; ?>

<?php get_sidebar() ?>
<?php get_footer(); ?>