	<form id="explore" accept-charset="utf-8" action="/explore" method="get" enctype="multipart/form-data" onsubmit="return validate_form(this)">
	<h3><span>Explore</span> Our Charts</h3>
	<h4>Subject</h4>
	<!-- <input type="hidden" id="ExploreSubject_" value="" name="data[Explore][Subject]" /> -->
	<select id="ExploreSubject" name="subjects">
		<option value="0">Select A Subject</option>

		<?php 
		
		function selectlist($tax){
		$terms = get_terms("$tax");
		$count = count($terms);
		if($count > 0){
		    echo '';
		    foreach ($terms as $term) {
		      echo '<option value="'.$term->name.'">'. $term->name . '</option>';     
		    }
		}
		} ?>
		
		
		<?php selectlist('subjects'); ?>


					<!-- <option value="18">Economy Track</option>
					<option value="11">Health</option>
					<option value="9">Income</option>
					<option value="15">International</option>
					<option value="12">Jobs</option>
					<option value="16">Mobility</option>
					<option value="8">Poverty</option>
					<option value="10">Wages</option>
					<option value="14">Wealth</option> -->
			</select>  
	<h4>Demographic</h4>
	<!-- <input type="hidden" id="ExploreDemographic_" value="" name="data[Explore][Demographic]"/> -->
	<select id="ExploreDemographic" name="demographic">
		<option value="0">Select A Demographic</option>

		<?php selectlist('demographic'); ?>

					<!-- <option value="3">Age</option>
					<option value="7">Education Level</option>
					<option value="4">Family Type</option>
					<option value="2">Gender</option>
					<option value="6">Immigration Status</option>
					<option value="1">Race & Ethnicity</option>
					<option value="5">Union Membership</option> -->
			</select>
	<p class="error">Select a subject or demographic</p>
	<input type="image" src="<?php echo get_stylesheet_directory_uri() ?>/img/form/btn-submit.png" alt="Submit form"/>				
</form>