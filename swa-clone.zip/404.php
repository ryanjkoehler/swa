<?php
/**
* Description of Template goes here
*
Template Name: Page
*/

?>
<?php doUrlForwarding(); ?>
<?php get_header(); ?>


<?php if(have_posts()) : while(have_posts()) : the_post(); ?>

	<div id="intro">
	<h1><?php the_title(); ?></h1>
	<?php the_content(); ?>
	</div>	

</div>

<?php endwhile; else : ?>

	<div id="intro">

404: Page not found.

		</div>
			</div>	


<?php endif; ?>

<?php get_sidebar() ?>
    
<?php get_footer(); ?>