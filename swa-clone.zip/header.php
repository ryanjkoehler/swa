<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */
?>

<!doctype html>  

<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
	<title><?php
		/*
		 * Print the <title> tag based on what is being viewed.
		 */
		global $page, $paged;

		wp_title( '|', true, 'right' );

		// Add the blog name.
		bloginfo( 'name' );

		// Add the blog description for the home/front page.
/*		$site_description = get_bloginfo( 'description', 'display' );
		if ( $site_description && ( is_home() || is_front_page() ) )
			echo " | $site_description";
*/
		// Add a page number if necessary:
		if ( $paged >= 2 || $page >= 2 )
			echo ' | ' . sprintf( __( 'Page %s', 'twentyten' ), max( $paged, $page ) );

		?></title>
	<meta name="description" content="State of Working America homepage">
	<meta name="keywords" content="home, page, epi, state of working america">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="imagetoolbar" content="no">

	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() ?>/css/style.css?v=2">
		<!--[if lt IE 9]>
		<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() ?>/css/print-ie.css" media="print">
	<![endif]--> 
	
	<!-- All JavaScript at the bottom, except for Modernizr which enables HTML5 elements & feature detects -->
	<script src="<?php echo get_stylesheet_directory_uri() ?>/js/libs/modernizr-1.6.min.js"></script>
	<!--[if lt IE 7 ]>
		<script src="<?php echo get_stylesheet_directory_uri() ?>/js/libs/dd_belatedpng.js"></script>
		<script> DD_belatedPNG.fix('img, .png_bg'); //fix any <img> or .png_bg background-images </script>
	<![endif]-->
	
	<!--[if lt IE 9]>
		<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() ?>/css/print-ie.css" media="print">
	<![endif]--> 
	
	
	
	<?php if(is_page_template('page-interactive.php')) { ?>
		
		
		<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri() ?>/js/swfobject.js" ></script>
		<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri() ?>/js/swfaddress.js"></script>
		<script type="text/javascript">
			var flashvars = {dataPath:'<?php echo get_stylesheet_directory_uri() ?>/flash/income.csv'};
			var params = {allowNetworking:"all", hasPriority:"true", allowScriptAccess:"always", wmode:"transparent"};
			var attributes = {id:'income', name:'income'};
			swfobject.embedSWF("<?php echo get_stylesheet_directory_uri() ?>/flash/income.swf", "fcontent", "940", "575", "9.0.115", false, flashvars, params, attributes);
		</script>



		
		
	<?php } ?>
	
	
		
		
		
	<script type="text/javascript">

	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-5401971-12']);
	  _gaq.push(['_trackPageview']);

	  (function() {
	    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();

	</script>
<?php wp_head(); ?>
</head>

<body<?php if (is_front_page()) {?> class="home"<?php } ?>>
	<div id="container"<?php if ( is_page_template('page-interactive.php') ) { ?> class="clearfix interactive"<?php } ?>>
		<div id="header" class="png_bg">
	    	<a class="visuallyhidden" href="#main">Skip to main content</a>
			<div id="identity"><a href="/"><span class="visuallyhidden">Economic Policy Institute - The State Of Working America</span></a></div>

							<?php
							if(function_exists('wp_nav_menu')) {
							wp_nav_menu(array(
							'theme_location' => 'main-nav',
							'container' => '',
			//				'container_id' => 'nav',
							'menu_id' => 'nav',
			//				'fallback_cb' => 'topnav_fallback',
							));
							} else {
							?>


			<ul id="nav" class="clearfix">
				<li><a href="/pages/about">About The State of Working America</a></li>
				<li class="dd">			
					<a href="#">Featured Stories</a>
					<ul>
													<li><a href="/features/view/3"> Economic Landscape</a></li>
													<li><a href="/features/view/2">Great Recession</a></li>
													<li><a href="/features/view/1">Inequality</a></li>
											</ul>
				</li>
				<li class="dd">			
					<a href="#">Subjects</a>
					<ul>
													<li><a href="/charts/subject/18">Economy Track</a></li>
													<li><a href="/charts/subject/11">Health</a></li>
													<li><a href="/charts/subject/9">Income</a></li>
													<li><a href="/charts/subject/15">International</a></li>
													<li><a href="/charts/subject/12">Jobs</a></li>
													<li><a href="/charts/subject/16">Mobility</a></li>
													<li><a href="/charts/subject/8">Poverty</a></li>
													<li><a href="/charts/subject/10">Wages</a></li>
													<li><a href="/charts/subject/14">Wealth</a></li>
											</ul>
				</li>
				<li class="dd">			
					<a href="#">Demographics</a>
					<ul>
													<li><a href="/charts/demographic/3">Age</a></li>
													<li><a href="/charts/demographic/7">Education Level</a></li>
													<li><a href="/charts/demographic/4">Family Type</a></li>
													<li><a href="/charts/demographic/2">Gender</a></li>
													<li><a href="/charts/demographic/6">Immigration Status</a></li>
													<li><a href="/charts/demographic/1">Race &amp; Ethnicity</a></li>
													<li><a href="/charts/demographic/5">Union Membership</a></li>
											</ul>
				</li>
			</ul>
	
	<?php } ?>
			
			
			<div id="search" class="clearfix">
				
			<div id="essearchlinks" style="color: #fff">
				
				<a href="/charts/asearch">Advanced Search</a> | 
				<a href="/chart-index">Chart Index</a>
			</div>
							
								
				
				<!-- <form name="search" id="SearchForm" method="post" action="/charts/search" accept-charset="utf-8"><div style="display:none;"><input type="hidden" name="_method" value="POST" /></div><label for="search-text" class="visuallyhidden">Search</label><input name="data[Search][q]" type="text" id="search-text" class="search-text" placeholder="Search" /><input type="image" src="<?php echo get_stylesheet_directory_uri() ?>/img/form/search-go.png" alt="Search submit button" /></form>			</div> -->
				<form name="search" id="SearchForm" method="get" action="/" accept-charset="utf-8"><label for="search-text" class="visuallyhidden">Search</label><input name="s" type="text" id="search-text" class="search-text" placeholder="Search" /><input type="image" src="<?php echo get_stylesheet_directory_uri() ?>/img/form/search-go.png" alt="Search submit button" /></form>			</div>
		</div>
    
		<div id="main-content" class="clearfix">
			<?php if(!is_page_template('page-interactive.php')) { ?>
			<div id="main"<?php if(is_category()) {echo ' class="results"';} ?>>
			<?php } ?>			
