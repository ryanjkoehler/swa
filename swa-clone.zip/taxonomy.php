<?php
/**
 * The template for displaying Category Archive pages.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */
?>

<?php get_header(); ?>

<?php if( is_tax() ) {
    global $wp_query;
    $term = $wp_query->get_queried_object();
    $taxonomy = $term->taxonomy; // This is the Taxonomy Title
	$taxonomy_term = $term->name; 
} ?>

<h2 class="sp-header"><?php echo $taxonomy; /*** This is the title of the taxonomy -- such as "Subjects" or "Demographics" ***/ ?></h2> 
<div id="intro">
<h1><?php echo $taxonomy_term; /*** This is the term you're looking at -- such as "Health" or "Race & Ethnicity" ***/ ?></h1>
</div>

<?php get_template_part('loop', 'charts') ?>

</div>



<?php get_sidebar() ?>
    
<?php get_footer(); ?>